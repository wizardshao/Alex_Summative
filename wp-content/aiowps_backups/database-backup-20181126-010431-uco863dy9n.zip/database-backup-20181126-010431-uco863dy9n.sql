-- All In One WP Security & Firewall 4.3.7.2
-- MySQL dump
-- 2018-11-26 01:04:31

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_comments` VALUES("1","1","A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2018-11-20 02:43:28","2018-11-20 02:43:28","Hi, this is a comment.
To get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.
Commenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.","0","1","","","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://localhost/immigration","yes");
INSERT INTO `wp_options` VALUES("2","home","http://localhost/immigration","yes");
INSERT INTO `wp_options` VALUES("3","blogname","legaleagle","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Just another WordPress site","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","st.havac@gmail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/index.php/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:4:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:37:\"post-types-order/post-types-order.php\";i:3;s:24:\"wordpress-seo/wp-seo.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","","no");
INSERT INTO `wp_options` VALUES("40","template","law-master","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","law-master","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","38590","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("92","show_comments_cookies_opt_in","0","yes");
INSERT INTO `wp_options` VALUES("93","initial_db_version","38590","yes");
INSERT INTO `wp_options` VALUES("94","wp_user_roles","a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("95","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("96","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("97","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","sidebars_widgets","a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("102","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("103","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("104","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","nonce_key","V[-}$i>/b.BGT~uF9cCZ%Z=2qa~)%WRaPs=>>[:K,-S5 kUL?_LA-!2ZXO.y7`>t","no");
INSERT INTO `wp_options` VALUES("109","nonce_salt","HU(.i:2MNNb|:XRJ/bhG?xS1r23f`Rsc_Ru8sc2uOAnu>f[54 GY%SO+-SUx Qj_","no");
INSERT INTO `wp_options` VALUES("110","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("113","cron","a:8:{i:1543196608;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1543197793;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1543200208;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1543200235;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1543274417;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1543280593;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1543280596;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("114","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1542681968;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES("118","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.8-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1543187815;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("123","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1543187816;s:7:\"checked\";a:1:{s:10:\"law-master\";s:3:\"2.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("124","auth_key","i@rNz`wlU-GythgM:3TZ:lDjKD)x.h1V~qw4*7ATd`!~:B3,514U 81S`ECYz}RY","no");
INSERT INTO `wp_options` VALUES("125","auth_salt",")A^tiyggLH5G_,X/8L[/0fZ79G]n*q3~6HD;Oc>lzsHjU=P n^[qlm{-WF=m4:Sa","no");
INSERT INTO `wp_options` VALUES("126","logged_in_key","o[A(MdBbz`an3+UD[w9Em<Y{xO+4qj.]lQ_WGt `,|/^<bjg1G{[ov+.=OMxd:TK","no");
INSERT INTO `wp_options` VALUES("127","logged_in_salt","Al]dKnMBRjZ@]A-Jxj_fZiSd:+ZwD^Fl]!Qh5ty]i 9CTwZLF:WTRg))c=^+Hnfa","no");
INSERT INTO `wp_options` VALUES("129","_site_transient_timeout_browser_cb17bca484772c4ed7af49f5b89d5c97","1543286614","no");
INSERT INTO `wp_options` VALUES("130","_site_transient_browser_cb17bca484772c4ed7af49f5b89d5c97","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"62.0.3202.94\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("131","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("146","current_theme","Law Master","yes");
INSERT INTO `wp_options` VALUES("147","theme_mods_star-law-master","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:9:\"main-menu\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1542766263;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("148","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("157","recently_activated","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("158","acf_version","5.7.7","yes");
INSERT INTO `wp_options` VALUES("159","cpto_options","a:7:{s:23:\"show_reorder_interfaces\";a:3:{s:4:\"post\";s:4:\"show\";s:10:\"attachment\";s:4:\"show\";s:5:\"slide\";s:4:\"show\";}s:8:\"autosort\";i:1;s:9:\"adminsort\";i:1;s:18:\"use_query_ASC_DESC\";s:0:\"\";s:17:\"archive_drag_drop\";i:1;s:10:\"capability\";s:14:\"manage_options\";s:21:\"navigation_sort_apply\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("160","CPT_configured","TRUE","yes");
INSERT INTO `wp_options` VALUES("161","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("168","theme_mods_law-master","a:5:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:9:\"main-menu\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:12:\"logo_setting\";s:0:\"\";s:21:\"heading_color_setting\";s:7:\"#22acd6\";}","yes");
INSERT INTO `wp_options` VALUES("181","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("201","type_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("215","_site_transient_timeout_theme_roots","1543189616","no");
INSERT INTO `wp_options` VALUES("216","_site_transient_theme_roots","a:1:{s:10:\"law-master\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("217","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1543194192;s:7:\"checked\";a:6:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.7.7\";s:19:\"akismet/akismet.php\";s:5:\"4.0.8\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:7:\"4.3.7.2\";s:9:\"hello.php\";s:3:\"1.7\";s:37:\"post-types-order/post-types-order.php\";s:7:\"1.9.3.9\";s:24:\"wordpress-seo/wp-seo.php\";s:5:\"9.2.1\";}s:8:\"response\";a:1:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"4.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:3:\"5.0\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:5:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.7.7\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.7.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:7:\"4.3.7.2\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}s:37:\"post-types-order/post-types-order.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:30:\"w.org/plugins/post-types-order\";s:4:\"slug\";s:16:\"post-types-order\";s:6:\"plugin\";s:37:\"post-types-order/post-types-order.php\";s:11:\"new_version\";s:7:\"1.9.3.9\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/post-types-order/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/post-types-order.1.9.3.9.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/post-types-order/assets/icon-128x128.png?rev=1226428\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/post-types-order/assets/banner-1544x500.png?rev=1675574\";s:2:\"1x\";s:71:\"https://ps.w.org/post-types-order/assets/banner-772x250.png?rev=1429949\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:5:\"9.2.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/wordpress-seo.9.2.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}","no");
INSERT INTO `wp_options` VALUES("220","_site_transient_timeout_available_translations","1543203347","no");
INSERT INTO `wp_options` VALUES("221","_site_transient_available_translations","a:113:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-17 18:13:01\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-22 03:45:21\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-04 08:43:29\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.5/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-05 11:37:23\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-21 15:34:42\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-29 21:28:23\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 17:08:36\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-14 19:51:46\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-07-06 08:46:24\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:47:36\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-25 13:19:31\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:48:22\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-25 12:30:09\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.8/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-13 08:48:48\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 16:14:01\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-04 13:34:08\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-29 04:07:23\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 23:34:56\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-01 02:03:58\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-09 14:53:42\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-10 17:20:09\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-15 16:32:57\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-15 15:46:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 23:17:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 16:20:18\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 20:43:09\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-04 08:05:41\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-05 07:24:22\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-08 18:24:55\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 16:02:42\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-02 09:10:15\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-12 20:01:58\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-19 09:43:51\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 10:29:39\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 13:16:13\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-19 15:55:54\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-01 10:30:44\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-02 06:28:35\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-21 14:15:57\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-22 02:28:45\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 17:12:13\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-13 21:42:46\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-30 20:27:25\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-11 00:57:26\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-29 08:41:27\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-18 11:11:49\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-29 08:41:56\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-10 17:50:37\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-21 07:25:37\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-25 18:52:37\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 09:30:48\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.5/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-05 14:41:09\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-01 17:58:21\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 16:21:25\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-31 08:30:58\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-01 13:20:12\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-02 20:59:54\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 15:35:13\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-02 17:08:41\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-07 21:08:54\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-29 07:32:40\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-06 08:37:04\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-11 06:46:15\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-06 02:26:39\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-19 20:31:12\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-09 00:56:52\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-17 22:20:52\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}","no");
INSERT INTO `wp_options` VALUES("223","_transient_timeout_plugin_slugs","1543280597","no");
INSERT INTO `wp_options` VALUES("224","_transient_plugin_slugs","a:6:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:9:\"hello.php\";i:4;s:37:\"post-types-order/post-types-order.php\";i:5;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `wp_options` VALUES("225","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("226","aio_wp_security_configs","a:90:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:18:\"st.havac@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"dbp6gfwy4h3cv4v7llys\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"nexo2lwk54266lbfp0od\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:4;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:2;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:18:\"st.havac@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:18:\"st.havac@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("227","_transient_timeout_users_online","1543195994","no");
INSERT INTO `wp_options` VALUES("228","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1543194194;s:10:\"ip_address\";s:3:\"::1\";}}","no");
INSERT INTO `wp_options` VALUES("230","wpseo","a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:5:\"9.2.1\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1543194196;}","yes");
INSERT INTO `wp_options` VALUES("231","wpseo_titles","a:102:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:13:\"title-section\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-section\";s:0:\"\";s:15:\"noindex-section\";b:0;s:16:\"showdate-section\";b:0;s:26:\"display-metabox-pt-section\";b:1;s:26:\"post_types-section-maintax\";i:0;s:16:\"title-usefullink\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-usefullink\";s:0:\"\";s:18:\"noindex-usefullink\";b:0;s:19:\"showdate-usefullink\";b:0;s:29:\"display-metabox-pt-usefullink\";b:1;s:29:\"post_types-usefullink-maintax\";i:0;s:12:\"title-lawyer\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:15:\"metadesc-lawyer\";s:0:\"\";s:14:\"noindex-lawyer\";b:0;s:15:\"showdate-lawyer\";b:0;s:25:\"display-metabox-pt-lawyer\";b:1;s:25:\"post_types-lawyer-maintax\";i:0;s:17:\"title-testimonial\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:20:\"metadesc-testimonial\";s:0:\"\";s:19:\"noindex-testimonial\";b:0;s:20:\"showdate-testimonial\";b:0;s:30:\"display-metabox-pt-testimonial\";b:1;s:30:\"post_types-testimonial-maintax\";i:0;s:20:\"title-practicingarea\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:23:\"metadesc-practicingarea\";s:0:\"\";s:22:\"noindex-practicingarea\";b:0;s:23:\"showdate-practicingarea\";b:0;s:33:\"display-metabox-pt-practicingarea\";b:1;s:33:\"post_types-practicingarea-maintax\";i:0;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:14:\"title-tax-type\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:17:\"metadesc-tax-type\";s:0:\"\";s:24:\"display-metabox-tax-type\";b:1;s:16:\"noindex-tax-type\";b:0;s:22:\"taxonomy-type-ptparent\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("232","wpseo_social","a:20:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("233","wpseo_flush_rewrite","1","yes");
INSERT INTO `wp_options` VALUES("234","_transient_timeout_wpseo_link_table_inaccessible","1574730196","no");
INSERT INTO `wp_options` VALUES("235","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("236","_transient_timeout_wpseo_meta_table_inaccessible","1574730196","no");
INSERT INTO `wp_options` VALUES("237","_transient_wpseo_meta_table_inaccessible","0","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=597 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("3","5","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("4","5","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("5","5","_menu_item_object_id","5");
INSERT INTO `wp_postmeta` VALUES("6","5","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("7","5","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("8","5","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("9","5","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("10","5","_menu_item_url","http://localhost/immigration/");
INSERT INTO `wp_postmeta` VALUES("11","5","_menu_item_orphaned","1542755712");
INSERT INTO `wp_postmeta` VALUES("12","6","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("13","6","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("14","6","_menu_item_object_id","2");
INSERT INTO `wp_postmeta` VALUES("15","6","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("16","6","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("17","6","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("18","6","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("19","6","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("20","6","_menu_item_orphaned","1542755712");
INSERT INTO `wp_postmeta` VALUES("21","2","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("22","2","_wp_trash_meta_time","1542756007");
INSERT INTO `wp_postmeta` VALUES("23","2","_wp_desired_post_slug","sample-page");
INSERT INTO `wp_postmeta` VALUES("24","3","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("25","3","_wp_trash_meta_time","1542756008");
INSERT INTO `wp_postmeta` VALUES("26","3","_wp_desired_post_slug","privacy-policy");
INSERT INTO `wp_postmeta` VALUES("27","9","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("28","9","_edit_lock","1543191604:1");
INSERT INTO `wp_postmeta` VALUES("29","11","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("30","11","_edit_lock","1542756090:1");
INSERT INTO `wp_postmeta` VALUES("31","11","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("32","11","_wp_trash_meta_time","1542756240");
INSERT INTO `wp_postmeta` VALUES("33","11","_wp_desired_post_slug","about");
INSERT INTO `wp_postmeta` VALUES("34","15","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("35","15","_edit_lock","1542756317:1");
INSERT INTO `wp_postmeta` VALUES("36","17","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("37","17","_edit_lock","1542756329:1");
INSERT INTO `wp_postmeta` VALUES("38","19","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("39","19","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("40","19","_menu_item_object_id","19");
INSERT INTO `wp_postmeta` VALUES("41","19","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("42","19","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("43","19","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("44","19","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("45","19","_menu_item_url","http://localhost/immigration/");
INSERT INTO `wp_postmeta` VALUES("46","19","_menu_item_orphaned","1542756632");
INSERT INTO `wp_postmeta` VALUES("47","20","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("48","20","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("49","20","_menu_item_object_id","15");
INSERT INTO `wp_postmeta` VALUES("50","20","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("51","20","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("52","20","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("53","20","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("54","20","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("55","20","_menu_item_orphaned","1542756632");
INSERT INTO `wp_postmeta` VALUES("56","21","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("57","21","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("58","21","_menu_item_object_id","9");
INSERT INTO `wp_postmeta` VALUES("59","21","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("60","21","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("61","21","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("62","21","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("63","21","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("64","21","_menu_item_orphaned","1542756632");
INSERT INTO `wp_postmeta` VALUES("65","22","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("66","22","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("67","22","_menu_item_object_id","17");
INSERT INTO `wp_postmeta` VALUES("68","22","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("69","22","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("70","22","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("71","22","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("72","22","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("73","22","_menu_item_orphaned","1542756632");
INSERT INTO `wp_postmeta` VALUES("101","15","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("102","15","_wp_trash_meta_time","1542768589");
INSERT INTO `wp_postmeta` VALUES("103","15","_wp_desired_post_slug","contact-us");
INSERT INTO `wp_postmeta` VALUES("104","17","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("105","17","_wp_trash_meta_time","1542768590");
INSERT INTO `wp_postmeta` VALUES("106","17","_wp_desired_post_slug","useful-links");
INSERT INTO `wp_postmeta` VALUES("107","26","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("108","26","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("109","26","_menu_item_object_id","9");
INSERT INTO `wp_postmeta` VALUES("110","26","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("111","26","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("112","26","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("113","26","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("114","26","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("116","27","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("117","27","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("118","27","_menu_item_object_id","27");
INSERT INTO `wp_postmeta` VALUES("119","27","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("120","27","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("121","27","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("122","27","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("123","27","_menu_item_url","http://localhost/immigration/index.php/home/#about");
INSERT INTO `wp_postmeta` VALUES("125","28","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("126","28","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("127","28","_menu_item_object_id","28");
INSERT INTO `wp_postmeta` VALUES("128","28","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("129","28","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("130","28","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("131","28","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("132","28","_menu_item_url","http://localhost/immigration/index.php/home/#contact");
INSERT INTO `wp_postmeta` VALUES("134","30","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("135","30","_edit_lock","1542773447:1");
INSERT INTO `wp_postmeta` VALUES("136","31","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("137","31","_edit_lock","1542862127:1");
INSERT INTO `wp_postmeta` VALUES("138","33","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("139","33","_edit_lock","1542773477:1");
INSERT INTO `wp_postmeta` VALUES("140","34","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("141","34","_edit_lock","1542775358:1");
INSERT INTO `wp_postmeta` VALUES("142","9","sections","a:7:{i:0;s:2:\"33\";i:1;s:2:\"30\";i:2;s:2:\"39\";i:3;s:2:\"43\";i:4;s:2:\"31\";i:5;s:2:\"95\";i:6;s:3:\"107\";}");
INSERT INTO `wp_postmeta` VALUES("143","9","_sections","field_5bf4dcc0b9659");
INSERT INTO `wp_postmeta` VALUES("144","36","sections","a:3:{i:0;s:2:\"30\";i:1;s:2:\"33\";i:2;s:2:\"31\";}");
INSERT INTO `wp_postmeta` VALUES("145","36","_sections","field_5bf4dcc0b9659");
INSERT INTO `wp_postmeta` VALUES("146","37","sections","a:3:{i:0;s:2:\"30\";i:1;s:2:\"33\";i:2;s:2:\"31\";}");
INSERT INTO `wp_postmeta` VALUES("147","37","_sections","field_5bf4dcc0b9659");
INSERT INTO `wp_postmeta` VALUES("148","9","_wp_page_template","template_onepage.php");
INSERT INTO `wp_postmeta` VALUES("149","38","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("150","38","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("151","38","_menu_item_object_id","38");
INSERT INTO `wp_postmeta` VALUES("152","38","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("153","38","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("154","38","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("155","38","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("156","38","_menu_item_url","http://localhost/immigration/index.php/home/#practicing-areas");
INSERT INTO `wp_postmeta` VALUES("158","39","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("159","39","_edit_lock","1542843605:1");
INSERT INTO `wp_postmeta` VALUES("160","40","sections","a:4:{i:0;s:2:\"33\";i:1;s:2:\"30\";i:2;s:2:\"39\";i:3;s:2:\"31\";}");
INSERT INTO `wp_postmeta` VALUES("161","40","_sections","field_5bf4dcc0b9659");
INSERT INTO `wp_postmeta` VALUES("162","41","_wp_attached_file","2018/11/logo.jpg");
INSERT INTO `wp_postmeta` VALUES("163","41","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:154;s:4:\"file\";s:16:\"2018/11/logo.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"logo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("164","42","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("165","42","_wp_trash_meta_time","1542844062");
INSERT INTO `wp_postmeta` VALUES("166","43","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("167","43","_edit_lock","1542844139:1");
INSERT INTO `wp_postmeta` VALUES("168","44","sections","a:5:{i:0;s:2:\"33\";i:1;s:2:\"30\";i:2;s:2:\"39\";i:3;s:2:\"43\";i:4;s:2:\"31\";}");
INSERT INTO `wp_postmeta` VALUES("169","44","_sections","field_5bf4dcc0b9659");
INSERT INTO `wp_postmeta` VALUES("170","45","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("171","45","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("172","45","_menu_item_object_id","45");
INSERT INTO `wp_postmeta` VALUES("173","45","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("174","45","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("175","45","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("176","45","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("177","45","_menu_item_url","http://localhost/immigration/index.php/home/#useful-links");
INSERT INTO `wp_postmeta` VALUES("179","47","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("180","47","_edit_lock","1542858636:1");
INSERT INTO `wp_postmeta` VALUES("181","54","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("182","54","_edit_lock","1542858936:1");
INSERT INTO `wp_postmeta` VALUES("183","54","title","");
INSERT INTO `wp_postmeta` VALUES("184","54","_title","field_5bf604ae13d3a");
INSERT INTO `wp_postmeta` VALUES("185","54","item_one","AA Guides");
INSERT INTO `wp_postmeta` VALUES("186","54","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("187","54","item_two","Best Western");
INSERT INTO `wp_postmeta` VALUES("188","54","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("189","54","item_three","NZ Bed & Breakfast");
INSERT INTO `wp_postmeta` VALUES("190","54","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("191","54","item_four","");
INSERT INTO `wp_postmeta` VALUES("192","54","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("193","54","item_five","");
INSERT INTO `wp_postmeta` VALUES("194","54","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("195","55","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("196","55","_edit_lock","1542859380:1");
INSERT INTO `wp_postmeta` VALUES("197","55","item_one","SEEK");
INSERT INTO `wp_postmeta` VALUES("198","55","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("199","55","item_two","");
INSERT INTO `wp_postmeta` VALUES("200","55","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("201","55","item_three","");
INSERT INTO `wp_postmeta` VALUES("202","55","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("203","55","item_four","");
INSERT INTO `wp_postmeta` VALUES("204","55","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("205","55","item_five","");
INSERT INTO `wp_postmeta` VALUES("206","55","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("207","56","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("208","56","_edit_lock","1542858977:1");
INSERT INTO `wp_postmeta` VALUES("209","56","item_one","Auckland");
INSERT INTO `wp_postmeta` VALUES("210","56","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("211","56","item_two","Christchurch/Canterbury");
INSERT INTO `wp_postmeta` VALUES("212","56","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("213","56","item_three","Destination NZ");
INSERT INTO `wp_postmeta` VALUES("214","56","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("215","56","item_four","Wellington");
INSERT INTO `wp_postmeta` VALUES("216","56","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("217","56","item_five","");
INSERT INTO `wp_postmeta` VALUES("218","56","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("219","57","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("220","57","_edit_lock","1542860253:1");
INSERT INTO `wp_postmeta` VALUES("221","57","item_one","Business Information Zone");
INSERT INTO `wp_postmeta` VALUES("222","57","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("223","57","item_two","NZ Bizbuysell");
INSERT INTO `wp_postmeta` VALUES("224","57","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("225","57","item_three","NZ Companies Office");
INSERT INTO `wp_postmeta` VALUES("226","57","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("227","57","item_four","Trademe");
INSERT INTO `wp_postmeta` VALUES("228","57","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("229","57","item_five","");
INSERT INTO `wp_postmeta` VALUES("230","57","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("231","58","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("232","58","_edit_lock","1542859065:1");
INSERT INTO `wp_postmeta` VALUES("233","58","item_one","Immigration New Zealand");
INSERT INTO `wp_postmeta` VALUES("234","58","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("235","58","item_two","");
INSERT INTO `wp_postmeta` VALUES("236","58","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("237","58","item_three","");
INSERT INTO `wp_postmeta` VALUES("238","58","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("239","58","item_four","");
INSERT INTO `wp_postmeta` VALUES("240","58","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("241","58","item_five","");
INSERT INTO `wp_postmeta` VALUES("242","58","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("243","59","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("244","59","_edit_lock","1542859121:1");
INSERT INTO `wp_postmeta` VALUES("245","59","item_one","Bayleys");
INSERT INTO `wp_postmeta` VALUES("246","59","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("247","59","item_two","Barfoot & Thompson");
INSERT INTO `wp_postmeta` VALUES("248","59","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("249","59","item_three","Ray White");
INSERT INTO `wp_postmeta` VALUES("250","59","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("251","59","item_four","Realenz");
INSERT INTO `wp_postmeta` VALUES("252","59","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("253","59","item_five","");
INSERT INTO `wp_postmeta` VALUES("254","59","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("255","60","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("256","60","_edit_lock","1542859333:1");
INSERT INTO `wp_postmeta` VALUES("257","60","item_one","NZ Customs Service");
INSERT INTO `wp_postmeta` VALUES("258","60","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("259","60","item_two","Immigration New Zealand");
INSERT INTO `wp_postmeta` VALUES("260","60","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("261","60","item_three","Refugees as Survivors");
INSERT INTO `wp_postmeta` VALUES("262","60","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("263","60","item_four","WINZ");
INSERT INTO `wp_postmeta` VALUES("264","60","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("265","60","item_five","Auckland Refugee Council");
INSERT INTO `wp_postmeta` VALUES("266","60","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("267","61","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("268","61","_edit_lock","1542858897:1");
INSERT INTO `wp_postmeta` VALUES("269","61","item_one","SEEK");
INSERT INTO `wp_postmeta` VALUES("270","61","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("271","61","item_two","");
INSERT INTO `wp_postmeta` VALUES("272","61","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("273","61","item_three","");
INSERT INTO `wp_postmeta` VALUES("274","61","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("275","61","item_four","");
INSERT INTO `wp_postmeta` VALUES("276","61","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("277","61","item_five","");
INSERT INTO `wp_postmeta` VALUES("278","61","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("279","62","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("280","62","_edit_lock","1542859429:1");
INSERT INTO `wp_postmeta` VALUES("281","62","item_one","IELTS");
INSERT INTO `wp_postmeta` VALUES("282","62","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("283","62","item_two","Independent Schools of NZ");
INSERT INTO `wp_postmeta` VALUES("284","62","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("285","62","item_three","Ministry of Education");
INSERT INTO `wp_postmeta` VALUES("286","62","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("287","62","item_four","NZ Education Gazette");
INSERT INTO `wp_postmeta` VALUES("288","62","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("289","62","item_five","NZQA");
INSERT INTO `wp_postmeta` VALUES("290","62","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("291","63","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("292","63","_edit_lock","1542859469:1");
INSERT INTO `wp_postmeta` VALUES("293","63","item_one","NZ Herald (Auckland)");
INSERT INTO `wp_postmeta` VALUES("294","63","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("295","63","item_two","National Business Review");
INSERT INTO `wp_postmeta` VALUES("296","63","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("297","63","item_three","The Otago Daily Times");
INSERT INTO `wp_postmeta` VALUES("298","63","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("299","63","item_four","The Press Online (Christchurch)");
INSERT INTO `wp_postmeta` VALUES("300","63","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("301","63","item_five","");
INSERT INTO `wp_postmeta` VALUES("302","63","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("303","64","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("304","64","_edit_lock","1542859510:1");
INSERT INTO `wp_postmeta` VALUES("305","64","item_one","Emigrating to NZ");
INSERT INTO `wp_postmeta` VALUES("306","64","_item_one","field_5bf604c613d3b");
INSERT INTO `wp_postmeta` VALUES("307","64","item_two","Inland Revenue");
INSERT INTO `wp_postmeta` VALUES("308","64","_item_two","field_5bf6052413d3c");
INSERT INTO `wp_postmeta` VALUES("309","64","item_three","NZ Search Directory");
INSERT INTO `wp_postmeta` VALUES("310","64","_item_three","field_5bf6053613d3d");
INSERT INTO `wp_postmeta` VALUES("311","64","item_four","NZ Weather");
INSERT INTO `wp_postmeta` VALUES("312","64","_item_four","field_5bf6053f13d3e");
INSERT INTO `wp_postmeta` VALUES("313","64","item_five","NZ White/Yellow Pages");
INSERT INTO `wp_postmeta` VALUES("314","64","_item_five","field_5bf6054613d3f");
INSERT INTO `wp_postmeta` VALUES("315","65","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("316","65","_edit_lock","1542860492:1");
INSERT INTO `wp_postmeta` VALUES("317","66","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("318","66","_edit_lock","1542854683:1");
INSERT INTO `wp_postmeta` VALUES("319","67","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("320","67","_edit_lock","1542854675:1");
INSERT INTO `wp_postmeta` VALUES("321","68","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("322","68","_edit_lock","1542854729:1");
INSERT INTO `wp_postmeta` VALUES("323","69","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("324","69","_edit_lock","1542854702:1");
INSERT INTO `wp_postmeta` VALUES("325","70","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("326","70","_edit_lock","1542854694:1");
INSERT INTO `wp_postmeta` VALUES("327","71","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("328","71","_edit_lock","1542860271:1");
INSERT INTO `wp_postmeta` VALUES("329","74","_wp_attached_file","2018/11/business.jpg");
INSERT INTO `wp_postmeta` VALUES("330","74","_wp_attachment_metadata","a:5:{s:5:\"width\";i:314;s:6:\"height\";i:210;s:4:\"file\";s:20:\"2018/11/business.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"business-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"business-300x201.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("331","65","image","74");
INSERT INTO `wp_postmeta` VALUES("332","65","_image","field_5bf6145f3e112");
INSERT INTO `wp_postmeta` VALUES("333","65","content","We ensure that every business plan meets NZIS residence criteria.");
INSERT INTO `wp_postmeta` VALUES("334","65","_content","field_5bf614763e113");
INSERT INTO `wp_postmeta` VALUES("335","75","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("336","75","_edit_lock","1542937448:1");
INSERT INTO `wp_postmeta` VALUES("337","76","_wp_attached_file","2018/11/student_migrant.jpg");
INSERT INTO `wp_postmeta` VALUES("338","76","_wp_attachment_metadata","a:5:{s:5:\"width\";i:315;s:6:\"height\";i:210;s:4:\"file\";s:27:\"2018/11/student_migrant.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"student_migrant-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"student_migrant-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("339","75","image","76");
INSERT INTO `wp_postmeta` VALUES("340","75","_image","field_5bf6145f3e112");
INSERT INTO `wp_postmeta` VALUES("341","75","content","We assist International Students to come to New Zealand to be enrolled at all levels of education");
INSERT INTO `wp_postmeta` VALUES("342","75","_content","field_5bf614763e113");
INSERT INTO `wp_postmeta` VALUES("343","77","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("344","77","_edit_lock","1542861047:1");
INSERT INTO `wp_postmeta` VALUES("345","78","_wp_attached_file","2018/11/skilled-migrant.jpg");
INSERT INTO `wp_postmeta` VALUES("346","78","_wp_attachment_metadata","a:5:{s:5:\"width\";i:315;s:6:\"height\";i:210;s:4:\"file\";s:27:\"2018/11/skilled-migrant.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"skilled-migrant-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"skilled-migrant-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("347","77","image","78");
INSERT INTO `wp_postmeta` VALUES("348","77","_image","field_5bf6145f3e112");
INSERT INTO `wp_postmeta` VALUES("349","77","content","We assist migrants who qualify for residence under all aspects of NZIS criteria.");
INSERT INTO `wp_postmeta` VALUES("350","77","_content","field_5bf614763e113");
INSERT INTO `wp_postmeta` VALUES("351","79","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("352","79","_edit_lock","1542861595:1");
INSERT INTO `wp_postmeta` VALUES("353","80","_wp_attached_file","2018/11/deportation.jpg");
INSERT INTO `wp_postmeta` VALUES("354","80","_wp_attachment_metadata","a:5:{s:5:\"width\";i:315;s:6:\"height\";i:210;s:4:\"file\";s:23:\"2018/11/deportation.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"deportation-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"deportation-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("355","79","image","80");
INSERT INTO `wp_postmeta` VALUES("356","79","_image","field_5bf6145f3e112");
INSERT INTO `wp_postmeta` VALUES("357","79","content","Our specialist\'s are experienced in the immigration and deportation process.");
INSERT INTO `wp_postmeta` VALUES("358","79","_content","field_5bf614763e113");
INSERT INTO `wp_postmeta` VALUES("359","81","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("360","81","_edit_lock","1542860754:1");
INSERT INTO `wp_postmeta` VALUES("361","82","_wp_attached_file","2018/11/refugee.jpg");
INSERT INTO `wp_postmeta` VALUES("362","82","_wp_attachment_metadata","a:5:{s:5:\"width\";i:315;s:6:\"height\";i:210;s:4:\"file\";s:19:\"2018/11/refugee.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"refugee-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"refugee-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:16:\"ACT/Paul Jeffrey\";s:6:\"camera\";s:8:\"NIKON D4\";s:7:\"caption\";s:315:\"Children walking in the Zaatari Refugee Camp, located near Mafraq, Jordan. Opened in July, 2012, the camp holds upwards of 20,000 refugees from the civil war inside Syria. International Orthodox Christian Charities and other members of the ACT Alliance are active in the camp providing essential items and services.\";s:17:\"created_timestamp\";s:10:\"1353327658\";s:9:\"copyright\";s:12:\"Paul Jeffrey\";s:12:\"focal_length\";s:3:\"200\";s:3:\"iso\";s:3:\"160\";s:13:\"shutter_speed\";s:9:\"0.0003125\";s:5:\"title\";s:29:\"Syrian refugee camp in Jordan\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:24:{i:0;s:5:\"Syria\";i:1;s:6:\"Syrian\";i:2;s:16:\"Syrian Free Army\";i:3;s:9:\"civil war\";i:4;s:6:\"Jordan\";i:5;s:9:\"Jordanian\";i:6;s:8:\"refugees\";i:7;s:12:\"refugee camp\";i:8;s:5:\"UNHCR\";i:9;s:9:\"displaced\";i:10;s:9:\"civilians\";i:11;s:7:\"victims\";i:12;s:8:\"violence\";i:13;s:4:\"IOCC\";i:14;s:10:\"resistance\";i:15;s:11:\"middle east\";i:16;s:7:\"kingdom\";i:17;s:8:\"children\";i:18;s:4:\"boys\";i:19;s:5:\"girls\";i:20;s:4:\"walk\";i:21;s:7:\"walking\";i:22;s:5:\"tents\";i:23;s:7:\"shelter\";}}}");
INSERT INTO `wp_postmeta` VALUES("363","81","image","82");
INSERT INTO `wp_postmeta` VALUES("364","81","_image","field_5bf6145f3e112");
INSERT INTO `wp_postmeta` VALUES("365","81","content","We help refugees and people seeking asylum in New Zealand.");
INSERT INTO `wp_postmeta` VALUES("366","81","_content","field_5bf614763e113");
INSERT INTO `wp_postmeta` VALUES("367","83","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("368","83","_edit_lock","1542860581:1");
INSERT INTO `wp_postmeta` VALUES("369","84","_wp_attached_file","2018/11/family_0.jpg");
INSERT INTO `wp_postmeta` VALUES("370","84","_wp_attachment_metadata","a:5:{s:5:\"width\";i:315;s:6:\"height\";i:210;s:4:\"file\";s:20:\"2018/11/family_0.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"family_0-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"family_0-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:8:\"Bigstock\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("371","83","image","84");
INSERT INTO `wp_postmeta` VALUES("372","83","_image","field_5bf6145f3e112");
INSERT INTO `wp_postmeta` VALUES("373","83","content","We aim to improve mental health outcomes for children and young people, and their families.");
INSERT INTO `wp_postmeta` VALUES("374","83","_content","field_5bf614763e113");
INSERT INTO `wp_postmeta` VALUES("375","67","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("376","67","_wp_trash_meta_time","1542854824");
INSERT INTO `wp_postmeta` VALUES("377","67","_wp_desired_post_slug","skilled-immigration");
INSERT INTO `wp_postmeta` VALUES("378","66","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("379","66","_wp_trash_meta_time","1542854830");
INSERT INTO `wp_postmeta` VALUES("380","66","_wp_desired_post_slug","student-immigration");
INSERT INTO `wp_postmeta` VALUES("381","70","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("382","70","_wp_trash_meta_time","1542854841");
INSERT INTO `wp_postmeta` VALUES("383","70","_wp_desired_post_slug","criminal-and-mental-health");
INSERT INTO `wp_postmeta` VALUES("384","69","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("385","69","_wp_trash_meta_time","1542854850");
INSERT INTO `wp_postmeta` VALUES("386","69","_wp_desired_post_slug","refugee");
INSERT INTO `wp_postmeta` VALUES("387","68","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("388","68","_wp_trash_meta_time","1542854876");
INSERT INTO `wp_postmeta` VALUES("389","68","_wp_desired_post_slug","deportation");
INSERT INTO `wp_postmeta` VALUES("390","54","1","https://www.aa.co.nz/travel/");
INSERT INTO `wp_postmeta` VALUES("391","54","_1","field_5bf621dfd8b9f");
INSERT INTO `wp_postmeta` VALUES("392","61","link_one","https://www.seek.co.nz/");
INSERT INTO `wp_postmeta` VALUES("393","61","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("394","61","link_two","");
INSERT INTO `wp_postmeta` VALUES("395","61","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("396","61","link_three","");
INSERT INTO `wp_postmeta` VALUES("397","61","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("398","61","link_four","");
INSERT INTO `wp_postmeta` VALUES("399","61","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("400","61","link_five","");
INSERT INTO `wp_postmeta` VALUES("401","61","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("402","54","link_one","https://www.aa.co.nz/travel/");
INSERT INTO `wp_postmeta` VALUES("403","54","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("404","54","link_two","http://www.bestwestern.co.nz/");
INSERT INTO `wp_postmeta` VALUES("405","54","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("406","54","link_three","https://www.bnb.co.nz/");
INSERT INTO `wp_postmeta` VALUES("407","54","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("408","54","link_four","");
INSERT INTO `wp_postmeta` VALUES("409","54","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("410","54","link_five","");
INSERT INTO `wp_postmeta` VALUES("411","54","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("412","56","link_one","https://www.aucklandnz.com/");
INSERT INTO `wp_postmeta` VALUES("413","56","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("414","56","link_two","http://www.christchurchnz.com/asia/");
INSERT INTO `wp_postmeta` VALUES("415","56","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("416","56","link_three","http://www.destinationnz.co.nz/");
INSERT INTO `wp_postmeta` VALUES("417","56","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("418","56","link_four","https://wellington.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("419","56","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("420","56","link_five","");
INSERT INTO `wp_postmeta` VALUES("421","56","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("422","57","link_one","http://www.biz.org.nz/");
INSERT INTO `wp_postmeta` VALUES("423","57","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("424","57","link_two","https://www.nzbizbuysell.co.nz/");
INSERT INTO `wp_postmeta` VALUES("425","57","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("426","57","link_three","https://companies-register.companiesoffice.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("427","57","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("428","57","link_four","https://www.trademe.co.nz/");
INSERT INTO `wp_postmeta` VALUES("429","57","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("430","57","link_five","");
INSERT INTO `wp_postmeta` VALUES("431","57","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("432","58","link_one","https://www.immigration.govt.nz/new-zealand-visas");
INSERT INTO `wp_postmeta` VALUES("433","58","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("434","58","link_two","");
INSERT INTO `wp_postmeta` VALUES("435","58","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("436","58","link_three","");
INSERT INTO `wp_postmeta` VALUES("437","58","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("438","58","link_four","");
INSERT INTO `wp_postmeta` VALUES("439","58","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("440","58","link_five","");
INSERT INTO `wp_postmeta` VALUES("441","58","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("442","59","link_one","https://www.bayleys.co.nz/");
INSERT INTO `wp_postmeta` VALUES("443","59","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("444","59","link_two","https://www.barfoot.co.nz/");
INSERT INTO `wp_postmeta` VALUES("445","59","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("446","59","link_three","https://www.raywhitegroup.com/");
INSERT INTO `wp_postmeta` VALUES("447","59","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("448","59","link_four","https://www.realestate.co.nz/");
INSERT INTO `wp_postmeta` VALUES("449","59","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("450","59","link_five","");
INSERT INTO `wp_postmeta` VALUES("451","59","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("452","60","link_one","https://www.customs.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("453","60","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("454","60","link_two","https://www.immigration.govt.nz/new-zealand-visas");
INSERT INTO `wp_postmeta` VALUES("455","60","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("456","60","link_three","https://rasnz.co.nz/");
INSERT INTO `wp_postmeta` VALUES("457","60","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("458","60","link_four","https://www.workandincome.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("459","60","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("460","60","link_five","https://www.aucklandrefugeecouncil.org/");
INSERT INTO `wp_postmeta` VALUES("461","60","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("462","55","link_one","https://www.seek.co.nz/");
INSERT INTO `wp_postmeta` VALUES("463","55","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("464","55","link_two","");
INSERT INTO `wp_postmeta` VALUES("465","55","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("466","55","link_three","");
INSERT INTO `wp_postmeta` VALUES("467","55","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("468","55","link_four","");
INSERT INTO `wp_postmeta` VALUES("469","55","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("470","55","link_five","");
INSERT INTO `wp_postmeta` VALUES("471","55","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("472","62","link_one","https://www.ielts.org/");
INSERT INTO `wp_postmeta` VALUES("473","62","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("474","62","link_two","https://www.isnz.org.nz/");
INSERT INTO `wp_postmeta` VALUES("475","62","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("476","62","link_three","http://www.education.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("477","62","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("478","62","link_four","https://gazette.education.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("479","62","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("480","62","link_five","https://www.nzqa.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("481","62","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("482","63","link_one","https://www.nzherald.co.nz/");
INSERT INTO `wp_postmeta` VALUES("483","63","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("484","63","link_two","https://www.nbr.co.nz/");
INSERT INTO `wp_postmeta` VALUES("485","63","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("486","63","link_three","https://www.odt.co.nz/");
INSERT INTO `wp_postmeta` VALUES("487","63","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("488","63","link_four","https://www.stuff.co.nz/the-press");
INSERT INTO `wp_postmeta` VALUES("489","63","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("490","63","link_five","");
INSERT INTO `wp_postmeta` VALUES("491","63","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("492","64","link_one","https://www.enz.org/");
INSERT INTO `wp_postmeta` VALUES("493","64","_link_one","field_5bf6276775f07");
INSERT INTO `wp_postmeta` VALUES("494","64","link_two","https://www.ird.govt.nz/");
INSERT INTO `wp_postmeta` VALUES("495","64","_link_two","field_5bf627de87e4b");
INSERT INTO `wp_postmeta` VALUES("496","64","link_three","http://www.nzsearch.co.nz/");
INSERT INTO `wp_postmeta` VALUES("497","64","_link_three","field_5bf627eb05ab2");
INSERT INTO `wp_postmeta` VALUES("498","64","link_four","https://home.nzcity.co.nz/weather/Default.asp?c=w");
INSERT INTO `wp_postmeta` VALUES("499","64","_link_four","field_5bf627f8c4a52");
INSERT INTO `wp_postmeta` VALUES("500","64","link_five","https://whitepages.co.nz/");
INSERT INTO `wp_postmeta` VALUES("501","64","_link_five","field_5bf62801c4a53");
INSERT INTO `wp_postmeta` VALUES("502","65","icon","<i class=\"flaticon text-primary fas fa-briefcase\"></i>");
INSERT INTO `wp_postmeta` VALUES("503","65","_icon","field_5bf62e752550a");
INSERT INTO `wp_postmeta` VALUES("504","83","icon","<i class=\"flaticon text-primary fas fa-briefcase-medical\"></i>");
INSERT INTO `wp_postmeta` VALUES("505","83","_icon","field_5bf62e752550a");
INSERT INTO `wp_postmeta` VALUES("506","81","icon","<i class=\"flaticon text-primary fas fa-hand-holding-heart\"></i>");
INSERT INTO `wp_postmeta` VALUES("507","81","_icon","field_5bf62e752550a");
INSERT INTO `wp_postmeta` VALUES("508","77","icon","<i class=\"flaticon text-primary fas fa-hammer\"></i>");
INSERT INTO `wp_postmeta` VALUES("509","77","_icon","field_5bf62e752550a");
INSERT INTO `wp_postmeta` VALUES("510","75","icon","<i class=\"flaticon text-primary fas fa-user-graduate\"></i>");
INSERT INTO `wp_postmeta` VALUES("511","75","_icon","field_5bf62e752550a");
INSERT INTO `wp_postmeta` VALUES("512","79","icon","<i class=\"flaticon text-primary fas fa-hand-paper\"></i>");
INSERT INTO `wp_postmeta` VALUES("513","79","_icon","field_5bf62e752550a");
INSERT INTO `wp_postmeta` VALUES("514","92","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("515","92","_edit_lock","1543191510:1");
INSERT INTO `wp_postmeta` VALUES("516","93","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("517","93","_edit_lock","1543190923:1");
INSERT INTO `wp_postmeta` VALUES("518","94","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("519","94","_edit_lock","1543190660:1");
INSERT INTO `wp_postmeta` VALUES("520","95","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("521","95","_edit_lock","1542861846:1");
INSERT INTO `wp_postmeta` VALUES("522","96","sections","a:6:{i:0;s:2:\"33\";i:1;s:2:\"30\";i:2;s:2:\"39\";i:3;s:2:\"43\";i:4;s:2:\"31\";i:5;s:2:\"95\";}");
INSERT INTO `wp_postmeta` VALUES("523","96","_sections","field_5bf4dcc0b9659");
INSERT INTO `wp_postmeta` VALUES("524","97","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("525","97","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("526","97","_menu_item_object_id","97");
INSERT INTO `wp_postmeta` VALUES("527","97","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("528","97","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("529","97","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("530","97","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("531","97","_menu_item_url","http://localhost/immigration/index.php/home/#lawyers");
INSERT INTO `wp_postmeta` VALUES("533","98","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("534","98","_edit_lock","1543190652:1");
INSERT INTO `wp_postmeta` VALUES("535","94","intro","Ioana is a highly experienced senior staff solicitor who specialises in every aspect of refugee law and also immigration law. She has practised law for some 15 years and is particularly committed to all aspects of human rights law.<br>loana particularly looks after refugee claimants but also those seeking residence and mental health law.");
INSERT INTO `wp_postmeta` VALUES("536","94","_intro","field_5bf63aebb2d16");
INSERT INTO `wp_postmeta` VALUES("537","94","specialises","");
INSERT INTO `wp_postmeta` VALUES("538","94","_specialises","field_5bf63b12b2d17");
INSERT INTO `wp_postmeta` VALUES("539","93","intro","Trevor is a staff solicitor and was former Head of the English Department of a large Auckland school.");
INSERT INTO `wp_postmeta` VALUES("540","93","_intro","field_5bf63aebb2d16");
INSERT INTO `wp_postmeta` VALUES("541","93","specialises","");
INSERT INTO `wp_postmeta` VALUES("542","93","_specialises","field_5bf63b12b2d17");
INSERT INTO `wp_postmeta` VALUES("543","92","intro","");
INSERT INTO `wp_postmeta` VALUES("544","92","_intro","field_5bf63aebb2d16");
INSERT INTO `wp_postmeta` VALUES("545","92","specialises","Carole is the principal lawyer for the firm and a senior member of the immigration law team. She is a specialist in all aspects of human rights law. The law firm is a member of the New Zealand Law Society, NZILA and NZAMI. Carole has practised law for more than 25 years and is able to work and negotiate with Government Agencies as well as community groups in New Zealand.<br>Carole is responsible for Student, Residence and Skilled Migrant Immigration applications. Carole is directly in contact with education providers to ensure that students are matched with the most suitable school or institute. We assist with the provision of New Zealand and Australian students visas. Carole also works with Skilled Migrant, Investor as well as Long Term Business Visa applications.");
INSERT INTO `wp_postmeta` VALUES("546","92","_specialises","field_5bf63b12b2d17");
INSERT INTO `wp_postmeta` VALUES("547","101","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("548","101","_edit_lock","1542929454:1");
INSERT INTO `wp_postmeta` VALUES("549","101","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("550","101","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("551","101","_wp_trash_meta_time","1542929961");
INSERT INTO `wp_postmeta` VALUES("552","101","_wp_desired_post_slug","lawyer");
INSERT INTO `wp_postmeta` VALUES("553","94","intro_a","Ioana is a highly experienced senior staff solicitor who specialises in every aspect of refugee law and also immigration law. She has practised law for some 15 years and is particularly committed to all aspects of human rights law.");
INSERT INTO `wp_postmeta` VALUES("554","94","_intro_a","field_5bf63aebb2d16");
INSERT INTO `wp_postmeta` VALUES("555","94","intro_b","loana particularly looks after refugee claimants but also those seeking residence and mental health law.");
INSERT INTO `wp_postmeta` VALUES("556","94","_intro_b","field_5bf63b12b2d17");
INSERT INTO `wp_postmeta` VALUES("557","92","intro_a","Carole is the principal lawyer for the firm and a senior member of the immigration law team. She is a specialist in all aspects of human rights law. The law firm is a member of the New Zealand Law Society, NZILA and NZAMI. Carole has practised law for more than 25 years and is able to work and negotiate with Government Agencies as well as community groups in New Zealand.");
INSERT INTO `wp_postmeta` VALUES("558","92","_intro_a","field_5bf63aebb2d16");
INSERT INTO `wp_postmeta` VALUES("559","92","intro_b","Carole is responsible for Student, Residence and Skilled Migrant Immigration applications. Carole is directly in contact with education providers to ensure that students are matched with the most suitable school or institute. We assist with the provision of New Zealand and Australian students visas. Carole also works with Skilled Migrant, Investor as well as Long Term Business Visa applications.");
INSERT INTO `wp_postmeta` VALUES("560","92","_intro_b","field_5bf63b12b2d17");
INSERT INTO `wp_postmeta` VALUES("561","103","_edit_lock","1542935444:1");
INSERT INTO `wp_postmeta` VALUES("562","103","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("563","103","_wp_trash_meta_time","1542935478");
INSERT INTO `wp_postmeta` VALUES("564","104","_edit_lock","1542935755:1");
INSERT INTO `wp_postmeta` VALUES("565","104","_customize_restore_dismissed","1");
INSERT INTO `wp_postmeta` VALUES("566","93","intro_a","All aspects of immigration law High Court work Medical waivers Family reunification");
INSERT INTO `wp_postmeta` VALUES("567","93","_intro_a","field_5bf63aebb2d16");
INSERT INTO `wp_postmeta` VALUES("568","93","intro_b","");
INSERT INTO `wp_postmeta` VALUES("569","93","_intro_b","field_5bf63b12b2d17");
INSERT INTO `wp_postmeta` VALUES("570","93","content","<ul>
      <li>All aspects of immigration law</li>
      <li>High Court work</li>
      <li>Medical waivers</li>
      <li>Family reunification</li>
</ul>");
INSERT INTO `wp_postmeta` VALUES("571","93","_content","field_5bfb36effd675");
INSERT INTO `wp_postmeta` VALUES("572","92","content","




<ul>
      <li>All aspects of immigration law</li>
      <li>All residence applications</li>
      <li>All aspects of refugee law from first level to appeals and beyond</li>
      <li>Deportation law</li>
      <li>High Court judicial reviews and appeals through to the Supreme Court</li>
      <li>Mental health law</li>
      <li>Family law</li>
      <li>Criminal law</li>
      <li>Civil law</li>
      <li>Immigration and criminal discharges without conviction</li>
</ul>
");
INSERT INTO `wp_postmeta` VALUES("573","92","_content","field_5bfb36effd675");
INSERT INTO `wp_postmeta` VALUES("574","106","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("575","106","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("576","106","_menu_item_object_id","106");
INSERT INTO `wp_postmeta` VALUES("577","106","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("578","106","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("579","106","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("580","106","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("581","106","_menu_item_url","http://localhost/immigration/index.php/home/#testimonials");
INSERT INTO `wp_postmeta` VALUES("583","107","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("584","107","_edit_lock","1543191584:1");
INSERT INTO `wp_postmeta` VALUES("585","108","sections","a:7:{i:0;s:2:\"33\";i:1;s:2:\"30\";i:2;s:2:\"39\";i:3;s:2:\"43\";i:4;s:2:\"31\";i:5;s:2:\"95\";i:6;s:3:\"107\";}");
INSERT INTO `wp_postmeta` VALUES("586","108","_sections","field_5bf4dcc0b9659");
INSERT INTO `wp_postmeta` VALUES("587","109","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("588","109","_edit_lock","1543192387:1");
INSERT INTO `wp_postmeta` VALUES("589","110","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("590","110","_edit_lock","1543192361:1");
INSERT INTO `wp_postmeta` VALUES("591","109","content","Excellent service by Professional Visa Solutions. The staff is very prompt to the queries and keeps updating you with your visa status. I got my two year work visa within a month. I highly recommended these guys for all visa solutions.");
INSERT INTO `wp_postmeta` VALUES("592","109","_content","field_5bfb3faf22361");
INSERT INTO `wp_postmeta` VALUES("593","115","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("594","115","content","Humble and hardworking team who is always up for you. They listen to you carefully.I have always received one to one attention and they reviewed my file thoroughly to avoid delays and confusions. Thanks to Mr. Inder and the entire team at Provisas.");
INSERT INTO `wp_postmeta` VALUES("595","115","_content","field_5bfb3faf22361");
INSERT INTO `wp_postmeta` VALUES("596","115","_edit_lock","1543194044:1");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES("1","1","2018-11-20 02:43:28","2018-11-20 02:43:28","Welcome to WordPress. This is your first post. Edit or delete it, then start writing!","Hello world!","","publish","open","open","","hello-world","","","2018-11-20 02:43:28","2018-11-20 02:43:28","","0","http://localhost/immigration/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2018-11-20 02:43:28","2018-11-20 02:43:28","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://localhost/immigration/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","trash","closed","open","","sample-page__trashed","","","2018-11-20 23:20:07","2018-11-20 23:20:07","","0","http://localhost/immigration/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2018-11-20 02:43:28","2018-11-20 02:43:28","<h2>Who we are</h2><p>Our website address is: http://localhost/immigration.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>","Privacy Policy","","trash","closed","open","","privacy-policy__trashed","","","2018-11-20 23:20:08","2018-11-20 23:20:08","","0","http://localhost/immigration/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("4","1","2018-11-20 02:43:34","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2018-11-20 02:43:34","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=4","0","post","","0");
INSERT INTO `wp_posts` VALUES("5","1","2018-11-20 23:15:12","0000-00-00 00:00:00","","Home","","draft","closed","closed","","","","","2018-11-20 23:15:12","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=5","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("6","1","2018-11-20 23:15:12","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2018-11-20 23:15:12","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=6","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("7","1","2018-11-20 23:20:07","2018-11-20 23:20:07","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://localhost/immigration/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","inherit","closed","closed","","2-revision-v1","","","2018-11-20 23:20:07","2018-11-20 23:20:07","","2","http://localhost/immigration/index.php/2018/11/20/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("8","1","2018-11-20 23:20:08","2018-11-20 23:20:08","<h2>Who we are</h2><p>Our website address is: http://localhost/immigration.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>","Privacy Policy","","inherit","closed","closed","","3-revision-v1","","","2018-11-20 23:20:08","2018-11-20 23:20:08","","3","http://localhost/immigration/index.php/2018/11/20/3-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("9","1","2018-11-20 23:20:25","2018-11-20 23:20:25","Home","Home","","publish","closed","closed","","home","","","2018-11-26 00:22:24","2018-11-26 00:22:24","","0","http://localhost/immigration/?page_id=9","0","page","","0");
INSERT INTO `wp_posts` VALUES("10","1","2018-11-20 23:20:25","2018-11-20 23:20:25","Home","Home","","inherit","closed","closed","","9-revision-v1","","","2018-11-20 23:20:25","2018-11-20 23:20:25","","9","http://localhost/immigration/index.php/2018/11/20/9-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("11","1","2018-11-20 23:21:05","2018-11-20 23:21:05","About","About","","trash","closed","closed","","about__trashed","","","2018-11-20 23:24:00","2018-11-20 23:24:00","","0","http://localhost/immigration/?page_id=11","0","page","","0");
INSERT INTO `wp_posts` VALUES("12","1","2018-11-20 23:21:05","2018-11-20 23:21:05","About","About","","inherit","closed","closed","","11-revision-v1","","","2018-11-20 23:21:05","2018-11-20 23:21:05","","11","http://localhost/immigration/index.php/2018/11/20/11-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("13","1","2018-11-20 23:23:54","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-20 23:23:54","0000-00-00 00:00:00","","0","http://localhost/immigration/?page_id=13","0","page","","0");
INSERT INTO `wp_posts` VALUES("14","1","2018-11-20 23:23:55","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-20 23:23:55","0000-00-00 00:00:00","","0","http://localhost/immigration/?page_id=14","0","page","","0");
INSERT INTO `wp_posts` VALUES("15","1","2018-11-20 23:27:28","2018-11-20 23:27:28","Contact Us","Contact Us","","trash","closed","closed","","contact-us__trashed","","","2018-11-21 02:49:49","2018-11-21 02:49:49","","0","http://localhost/immigration/?page_id=15","0","page","","0");
INSERT INTO `wp_posts` VALUES("16","1","2018-11-20 23:27:28","2018-11-20 23:27:28","Contact Us","Contact Us","","inherit","closed","closed","","15-revision-v1","","","2018-11-20 23:27:28","2018-11-20 23:27:28","","15","http://localhost/immigration/index.php/2018/11/20/15-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("17","1","2018-11-20 23:27:52","2018-11-20 23:27:52","Useful Links","Useful Links","","trash","closed","closed","","useful-links__trashed","","","2018-11-21 02:49:50","2018-11-21 02:49:50","","0","http://localhost/immigration/?page_id=17","0","page","","0");
INSERT INTO `wp_posts` VALUES("18","1","2018-11-20 23:27:52","2018-11-20 23:27:52","Useful Links","Useful Links","","inherit","closed","closed","","17-revision-v1","","","2018-11-20 23:27:52","2018-11-20 23:27:52","","17","http://localhost/immigration/index.php/2018/11/20/17-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("19","1","2018-11-20 23:30:32","0000-00-00 00:00:00","","Home","","draft","closed","closed","","","","","2018-11-20 23:30:32","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=19","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("20","1","2018-11-20 23:30:32","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2018-11-20 23:30:32","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=20","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("21","1","2018-11-20 23:30:32","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2018-11-20 23:30:32","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=21","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("22","1","2018-11-20 23:30:32","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2018-11-20 23:30:32","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=22","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("26","1","2018-11-21 03:30:33","2018-11-21 03:30:33"," ","","","publish","closed","closed","","26","","","2018-11-26 00:23:39","2018-11-26 00:23:39","","0","http://localhost/immigration/?p=26","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("27","1","2018-11-21 04:05:32","2018-11-21 04:05:32","","About","","publish","closed","closed","","about","","","2018-11-26 00:23:39","2018-11-26 00:23:39","","0","http://localhost/immigration/?p=27","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("28","1","2018-11-21 04:06:19","2018-11-21 04:06:19","","Contact","","publish","closed","closed","","contact","","","2018-11-26 00:23:39","2018-11-26 00:23:39","","0","http://localhost/immigration/?p=28","7","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("29","1","2018-11-21 04:10:05","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-21 04:10:05","0000-00-00 00:00:00","","0","http://localhost/immigration/?post_type=acf-field-group&p=29","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("30","1","2018-11-21 04:13:11","2018-11-21 04:13:11","","About","","publish","closed","closed","","about","","","2018-11-21 04:13:11","2018-11-21 04:13:11","","0","http://localhost/immigration/?post_type=section&#038;p=30","1","section","","0");
INSERT INTO `wp_posts` VALUES("31","1","2018-11-21 04:13:20","2018-11-21 04:13:20","","Contact","","publish","closed","closed","","contact","","","2018-11-21 04:13:20","2018-11-21 04:13:20","","0","http://localhost/immigration/?post_type=section&#038;p=31","6","section","","0");
INSERT INTO `wp_posts` VALUES("32","1","2018-11-21 04:13:22","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-21 04:13:22","0000-00-00 00:00:00","","0","http://localhost/immigration/?post_type=section&p=32","0","section","","0");
INSERT INTO `wp_posts` VALUES("33","1","2018-11-21 04:13:38","2018-11-21 04:13:38","","Hero","","publish","closed","closed","","hero","","","2018-11-21 04:13:38","2018-11-21 04:13:38","","0","http://localhost/immigration/?post_type=section&#038;p=33","0","section","","0");
INSERT INTO `wp_posts` VALUES("34","1","2018-11-21 04:20:17","2018-11-21 04:20:17","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"post_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:20:\"template_onepage.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}","One Page Feilds","one-page-feilds","publish","closed","closed","","group_5bf4dcb79524e","","","2018-11-21 04:43:04","2018-11-21 04:43:04","","0","http://localhost/immigration/?post_type=acf-field-group&#038;p=34","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("35","1","2018-11-21 04:20:17","2018-11-21 04:20:17","a:12:{s:4:\"type\";s:12:\"relationship\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:7:\"section\";}s:8:\"taxonomy\";s:0:\"\";s:7:\"filters\";a:1:{i:0;s:9:\"post_type\";}s:8:\"elements\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:13:\"return_format\";s:2:\"id\";}","Sections","sections","publish","closed","closed","","field_5bf4dcc0b9659","","","2018-11-21 04:20:17","2018-11-21 04:20:17","","34","http://localhost/immigration/?post_type=acf-field&p=35","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES("36","1","2018-11-21 04:20:49","2018-11-21 04:20:49","Home","Home","","inherit","closed","closed","","9-revision-v1","","","2018-11-21 04:20:49","2018-11-21 04:20:49","","9","http://localhost/immigration/index.php/2018/11/21/9-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("37","1","2018-11-21 04:38:29","2018-11-21 04:38:29","Home","Home","","inherit","closed","closed","","9-revision-v1","","","2018-11-21 04:38:29","2018-11-21 04:38:29","","9","http://localhost/immigration/index.php/2018/11/21/9-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("38","1","2018-11-21 23:33:46","2018-11-21 23:33:46","","Practicing Areas","","publish","closed","closed","","practicing-areas","","","2018-11-26 00:23:39","2018-11-26 00:23:39","","0","http://localhost/immigration/?p=38","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("39","1","2018-11-21 23:42:25","2018-11-21 23:42:25","","Practicing Areas","","publish","closed","closed","","practicing-areas","","","2018-11-21 23:42:25","2018-11-21 23:42:25","","0","http://localhost/immigration/?post_type=section&#038;p=39","3","section","","0");
INSERT INTO `wp_posts` VALUES("40","1","2018-11-21 23:42:46","2018-11-21 23:42:46","Home","Home","","inherit","closed","closed","","9-revision-v1","","","2018-11-21 23:42:46","2018-11-21 23:42:46","","9","http://localhost/immigration/index.php/2018/11/21/9-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("41","1","2018-11-21 23:47:28","2018-11-21 23:47:28","","logo","","inherit","open","closed","","logo","","","2018-11-21 23:47:28","2018-11-21 23:47:28","","0","http://localhost/immigration/wp-content/uploads/2018/11/logo.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("42","1","2018-11-21 23:47:42","2018-11-21 23:47:42","{
    \"law-master::logo_setting\": {
        \"value\": \"http://localhost/immigration/wp-content/uploads/2018/11/logo.jpg\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-21 23:47:42\"
    }
}","","","trash","closed","closed","","86f4d860-db24-4306-865d-4a0a92394e87","","","2018-11-21 23:47:42","2018-11-21 23:47:42","","0","http://localhost/immigration/index.php/2018/11/21/86f4d860-db24-4306-865d-4a0a92394e87/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("43","1","2018-11-21 23:49:05","2018-11-21 23:49:05","","Useful Links","","publish","closed","closed","","useful-links","","","2018-11-21 23:49:05","2018-11-21 23:49:05","","0","http://localhost/immigration/?post_type=section&#038;p=43","5","section","","0");
INSERT INTO `wp_posts` VALUES("44","1","2018-11-21 23:51:35","2018-11-21 23:51:35","Home","Home","","inherit","closed","closed","","9-revision-v1","","","2018-11-21 23:51:35","2018-11-21 23:51:35","","9","http://localhost/immigration/index.php/2018/11/21/9-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("45","1","2018-11-21 23:52:25","2018-11-21 23:52:25","","Useful Links","","publish","closed","closed","","useful-links","","","2018-11-26 00:23:39","2018-11-26 00:23:39","","0","http://localhost/immigration/?p=45","6","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("46","1","2018-11-22 01:20:25","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-22 01:20:25","0000-00-00 00:00:00","","0","http://localhost/immigration/?post_type=usefullink&p=46","0","usefullink","","0");
INSERT INTO `wp_posts` VALUES("47","1","2018-11-22 01:24:37","2018-11-22 01:24:37","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:10:\"usefullink\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}","Useful Links Fields One","useful-links-fields-one","publish","closed","closed","","group_5bf604625a86e","","","2018-11-22 03:52:50","2018-11-22 03:52:50","","0","http://localhost/immigration/?post_type=acf-field-group&#038;p=47","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("49","1","2018-11-22 01:24:37","2018-11-22 01:24:37","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Item One","item_one","publish","closed","closed","","field_5bf604c613d3b","","","2018-11-22 03:50:45","2018-11-22 03:50:45","","47","http://localhost/immigration/?post_type=acf-field&#038;p=49","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES("50","1","2018-11-22 01:24:37","2018-11-22 01:24:37","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Item Two","item_two","publish","closed","closed","","field_5bf6052413d3c","","","2018-11-22 03:50:45","2018-11-22 03:50:45","","47","http://localhost/immigration/?post_type=acf-field&#038;p=50","1","acf-field","","0");
INSERT INTO `wp_posts` VALUES("51","1","2018-11-22 01:24:37","2018-11-22 01:24:37","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Item Three","item_three","publish","closed","closed","","field_5bf6053613d3d","","","2018-11-22 03:50:45","2018-11-22 03:50:45","","47","http://localhost/immigration/?post_type=acf-field&#038;p=51","2","acf-field","","0");
INSERT INTO `wp_posts` VALUES("52","1","2018-11-22 01:24:37","2018-11-22 01:24:37","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Item Four","item_four","publish","closed","closed","","field_5bf6053f13d3e","","","2018-11-22 03:50:45","2018-11-22 03:50:45","","47","http://localhost/immigration/?post_type=acf-field&#038;p=52","3","acf-field","","0");
INSERT INTO `wp_posts` VALUES("53","1","2018-11-22 01:24:37","2018-11-22 01:24:37","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Item Five","item_five","publish","closed","closed","","field_5bf6054613d3f","","","2018-11-22 03:50:45","2018-11-22 03:50:45","","47","http://localhost/immigration/?post_type=acf-field&#038;p=53","4","acf-field","","0");
INSERT INTO `wp_posts` VALUES("54","1","2018-11-22 01:25:24","2018-11-22 01:25:24","","Accommodation","","publish","closed","closed","","accommodation","","","2018-11-22 03:57:56","2018-11-22 03:57:56","","0","http://localhost/immigration/?post_type=usefullink&#038;p=54","1","usefullink","","0");
INSERT INTO `wp_posts` VALUES("55","1","2018-11-22 01:26:21","2018-11-22 01:26:21","","Employment","","publish","closed","closed","","employment","","","2018-11-22 04:05:24","2018-11-22 04:05:24","","0","http://localhost/immigration/?post_type=usefullink&#038;p=55","7","usefullink","","0");
INSERT INTO `wp_posts` VALUES("56","1","2018-11-22 01:27:03","2018-11-22 01:27:03","","Tourism","","publish","closed","closed","","tourism","","","2018-11-22 03:58:39","2018-11-22 03:58:39","","0","http://localhost/immigration/?post_type=usefullink&#038;p=56","2","usefullink","","0");
INSERT INTO `wp_posts` VALUES("57","1","2018-11-22 01:49:24","2018-11-22 01:49:24","","Business","","publish","closed","closed","","business","","","2018-11-22 04:09:45","2018-11-22 04:09:45","","0","http://localhost/immigration/?post_type=usefullink&#038;p=57","3","usefullink","","0");
INSERT INTO `wp_posts` VALUES("58","1","2018-11-22 01:51:03","2018-11-22 01:51:03","","Immigration Advisors","","publish","closed","closed","","immigration-advisors","","","2018-11-22 04:00:07","2018-11-22 04:00:07","","0","http://localhost/immigration/?post_type=usefullink&#038;p=58","4","usefullink","","0");
INSERT INTO `wp_posts` VALUES("59","1","2018-11-22 01:51:34","2018-11-22 01:51:34","","Real Estate","","publish","closed","closed","","real-estate","","","2018-11-22 04:01:01","2018-11-22 04:01:01","","0","http://localhost/immigration/?post_type=usefullink&#038;p=59","5","usefullink","","0");
INSERT INTO `wp_posts` VALUES("60","1","2018-11-22 01:52:33","2018-11-22 01:52:33","","Immigration & Customs","","publish","closed","closed","","immigration-customs","","","2018-11-22 04:04:36","2018-11-22 04:04:36","","0","http://localhost/immigration/?post_type=usefullink&#038;p=60","6","usefullink","","0");
INSERT INTO `wp_posts` VALUES("61","1","2018-11-22 01:52:45","2018-11-22 01:52:45","","Employment","","publish","closed","closed","","employment-2","","","2018-11-22 03:57:21","2018-11-22 03:57:21","","0","http://localhost/immigration/?post_type=usefullink&#038;p=61","0","usefullink","","0");
INSERT INTO `wp_posts` VALUES("62","1","2018-11-22 01:53:20","2018-11-22 01:53:20","","Education","","publish","closed","closed","","education","","","2018-11-22 04:06:12","2018-11-22 04:06:12","","0","http://localhost/immigration/?post_type=usefullink&#038;p=62","8","usefullink","","0");
INSERT INTO `wp_posts` VALUES("63","1","2018-11-22 01:53:54","2018-11-22 01:53:54","","News","","publish","closed","closed","","news","","","2018-11-22 04:06:52","2018-11-22 04:06:52","","0","http://localhost/immigration/?post_type=usefullink&#038;p=63","9","usefullink","","0");
INSERT INTO `wp_posts` VALUES("64","1","2018-11-22 01:54:35","2018-11-22 01:54:35","","Miscellaneous","","publish","closed","closed","","miscellaneous","","","2018-11-22 04:07:32","2018-11-22 04:07:32","","0","http://localhost/immigration/?post_type=usefullink&#038;p=64","10","usefullink","","0");
INSERT INTO `wp_posts` VALUES("65","1","2018-11-22 02:23:38","2018-11-22 02:23:38","","Business Immigration","","publish","closed","closed","","business-immigration","","","2018-11-22 04:23:04","2018-11-22 04:23:04","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=65","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("66","1","2018-11-22 02:23:45","2018-11-22 02:23:45","","Student Immigration","","trash","closed","closed","","student-immigration__trashed","","","2018-11-22 02:47:10","2018-11-22 02:47:10","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=66","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("67","1","2018-11-22 02:23:53","2018-11-22 02:23:53","","Skilled Immigration","","trash","closed","closed","","skilled-immigration__trashed","","","2018-11-22 02:47:04","2018-11-22 02:47:04","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=67","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("68","1","2018-11-22 02:24:00","2018-11-22 02:24:00","","Deportation","","trash","closed","closed","","deportation__trashed","","","2018-11-22 02:47:56","2018-11-22 02:47:56","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=68","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("69","1","2018-11-22 02:24:08","2018-11-22 02:24:08","","Refugee","","trash","closed","closed","","refugee__trashed","","","2018-11-22 02:47:30","2018-11-22 02:47:30","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=69","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("70","1","2018-11-22 02:24:17","2018-11-22 02:24:17","","Criminal and mental Health","","trash","closed","closed","","criminal-and-mental-health__trashed","","","2018-11-22 02:47:21","2018-11-22 02:47:21","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=70","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("71","1","2018-11-22 02:29:24","2018-11-22 02:29:24","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"practicingarea\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}","Areas Fields","areas-fields","publish","closed","closed","","group_5bf6144b7126e","","","2018-11-22 04:20:12","2018-11-22 04:20:12","","0","http://localhost/immigration/?post_type=acf-field-group&#038;p=71","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("72","1","2018-11-22 02:29:24","2018-11-22 02:29:24","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Image","image","publish","closed","closed","","field_5bf6145f3e112","","","2018-11-22 02:32:18","2018-11-22 02:32:18","","71","http://localhost/immigration/?post_type=acf-field&#038;p=72","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES("73","1","2018-11-22 02:29:24","2018-11-22 02:29:24","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Content","content","publish","closed","closed","","field_5bf614763e113","","","2018-11-22 02:29:24","2018-11-22 02:29:24","","71","http://localhost/immigration/?post_type=acf-field&p=73","1","acf-field","","0");
INSERT INTO `wp_posts` VALUES("74","1","2018-11-22 02:30:42","2018-11-22 02:30:42","","business","","inherit","open","closed","","business-2","","","2018-11-22 02:30:42","2018-11-22 02:30:42","","65","http://localhost/immigration/wp-content/uploads/2018/11/business.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("75","1","2018-11-22 02:43:59","2018-11-22 02:43:59","We assist students from all around the world to come to study in New Zealand-from beginner English lessons to students who come to study up to PHD levels. Some students come for the pleasure of the study itself, but others stay on and utilise their qualifications to start the immigration process. Work visas can lead to residence. We can assist and advise throughout the process from the decision making concerning the most helpful course of study.","Student Immigration","","publish","closed","closed","","student-immigration-2","","","2018-11-23 00:28:13","2018-11-23 00:28:13","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=75","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("76","1","2018-11-22 02:43:55","2018-11-22 02:43:55","","student_migrant","","inherit","open","closed","","student_migrant","","","2018-11-22 02:43:55","2018-11-22 02:43:55","","75","http://localhost/immigration/wp-content/uploads/2018/11/student_migrant.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("77","1","2018-11-22 02:44:35","2018-11-22 02:44:35","","Skilled Immigration","","publish","closed","closed","","skilled-immigration-2","","","2018-11-22 04:33:08","2018-11-22 04:33:08","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=77","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("78","1","2018-11-22 02:44:30","2018-11-22 02:44:30","","skilled-migrant","","inherit","open","closed","","skilled-migrant","","","2018-11-22 02:44:30","2018-11-22 02:44:30","","77","http://localhost/immigration/wp-content/uploads/2018/11/skilled-migrant.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("79","1","2018-11-22 02:45:02","2018-11-22 02:45:02","","Deportation","","publish","closed","closed","","deportation-2","","","2018-11-22 04:42:18","2018-11-22 04:42:18","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=79","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("80","1","2018-11-22 02:44:59","2018-11-22 02:44:59","","deportation","","inherit","open","closed","","deportation-2","","","2018-11-22 02:44:59","2018-11-22 02:44:59","","79","http://localhost/immigration/wp-content/uploads/2018/11/deportation.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("81","1","2018-11-22 02:45:32","2018-11-22 02:45:32","","Refugee","","publish","closed","closed","","refugee-2","","","2018-11-22 04:28:17","2018-11-22 04:28:17","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=81","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("82","1","2018-11-22 02:45:29","2018-11-22 02:45:29","","Syrian refugee camp in Jordan","Children walking in the Zaatari Refugee Camp, located near Mafraq, Jordan. Opened in July, 2012, the camp holds upwards of 20,000 refugees from the civil war inside Syria. International Orthodox Christian Charities and other members of the ACT Alliance are active in the camp providing essential items and services.","inherit","open","closed","","syrian-refugee-camp-in-jordan","","","2018-11-22 02:45:29","2018-11-22 02:45:29","","81","http://localhost/immigration/wp-content/uploads/2018/11/refugee.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("83","1","2018-11-22 02:46:02","2018-11-22 02:46:02","","Criminal and mental Health","","publish","closed","closed","","criminal-and-mental-health-2","","","2018-11-22 04:25:21","2018-11-22 04:25:21","","0","http://localhost/immigration/?post_type=practicingarea&#038;p=83","0","practicingarea","","0");
INSERT INTO `wp_posts` VALUES("84","1","2018-11-22 02:45:58","2018-11-22 02:45:58","","family_0","","inherit","open","closed","","family_0","","","2018-11-22 02:45:58","2018-11-22 02:45:58","","83","http://localhost/immigration/wp-content/uploads/2018/11/family_0.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("86","1","2018-11-22 03:50:45","2018-11-22 03:50:45","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Link One","link_one","publish","closed","closed","","field_5bf6276775f07","","","2018-11-22 03:51:03","2018-11-22 03:51:03","","47","http://localhost/immigration/?post_type=acf-field&#038;p=86","5","acf-field","","0");
INSERT INTO `wp_posts` VALUES("87","1","2018-11-22 03:52:08","2018-11-22 03:52:08","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Link Two","link_two","publish","closed","closed","","field_5bf627de87e4b","","","2018-11-22 03:52:08","2018-11-22 03:52:08","","47","http://localhost/immigration/?post_type=acf-field&p=87","6","acf-field","","0");
INSERT INTO `wp_posts` VALUES("88","1","2018-11-22 03:52:20","2018-11-22 03:52:20","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Link Three","link_three","publish","closed","closed","","field_5bf627eb05ab2","","","2018-11-22 03:52:20","2018-11-22 03:52:20","","47","http://localhost/immigration/?post_type=acf-field&p=88","7","acf-field","","0");
INSERT INTO `wp_posts` VALUES("89","1","2018-11-22 03:52:50","2018-11-22 03:52:50","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Link Four","link_four","publish","closed","closed","","field_5bf627f8c4a52","","","2018-11-22 03:52:50","2018-11-22 03:52:50","","47","http://localhost/immigration/?post_type=acf-field&p=89","8","acf-field","","0");
INSERT INTO `wp_posts` VALUES("90","1","2018-11-22 03:52:50","2018-11-22 03:52:50","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Link Five","link_five","publish","closed","closed","","field_5bf62801c4a53","","","2018-11-22 03:52:50","2018-11-22 03:52:50","","47","http://localhost/immigration/?post_type=acf-field&p=90","9","acf-field","","0");
INSERT INTO `wp_posts` VALUES("91","1","2018-11-22 04:20:12","2018-11-22 04:20:12","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Icon","icon","publish","closed","closed","","field_5bf62e752550a","","","2018-11-22 04:20:12","2018-11-22 04:20:12","","71","http://localhost/immigration/?post_type=acf-field&p=91","2","acf-field","","0");
INSERT INTO `wp_posts` VALUES("92","1","2018-11-22 04:42:46","2018-11-22 04:42:46","","Carole Curtis","","publish","closed","closed","","carole-curtis","","","2018-11-26 00:13:15","2018-11-26 00:13:15","","0","http://localhost/immigration/?post_type=lawyer&#038;p=92","0","lawyer","","0");
INSERT INTO `wp_posts` VALUES("93","1","2018-11-22 04:42:56","2018-11-22 04:42:56","","Trevor Zohs","","publish","closed","closed","","trevor-zohs","","","2018-11-26 00:10:47","2018-11-26 00:10:47","","0","http://localhost/immigration/?post_type=lawyer&#038;p=93","0","lawyer","","0");
INSERT INTO `wp_posts` VALUES("94","1","2018-11-22 04:43:03","2018-11-22 04:43:03","","loana Uca","","publish","closed","closed","","loana-uca","","","2018-11-23 00:14:36","2018-11-23 00:14:36","","0","http://localhost/immigration/?post_type=lawyer&#038;p=94","0","lawyer","","0");
INSERT INTO `wp_posts` VALUES("95","1","2018-11-22 04:46:28","2018-11-22 04:46:28","","Lawyers","","publish","closed","closed","","lawyers","","","2018-11-22 04:46:28","2018-11-22 04:46:28","","0","http://localhost/immigration/?post_type=section&#038;p=95","2","section","","0");
INSERT INTO `wp_posts` VALUES("96","1","2018-11-22 04:46:56","2018-11-22 04:46:56","Home","Home","","inherit","closed","closed","","9-revision-v1","","","2018-11-22 04:46:56","2018-11-22 04:46:56","","9","http://localhost/immigration/index.php/2018/11/22/9-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("97","1","2018-11-22 04:47:51","2018-11-22 04:47:51","","Lawyers","","publish","closed","closed","","lawyers","","","2018-11-26 00:23:39","2018-11-26 00:23:39","","0","http://localhost/immigration/?p=97","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("98","1","2018-11-22 05:15:04","2018-11-22 05:15:04","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:6:\"lawyer\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}","Lawyers Fields","lawyers-fields","publish","closed","closed","","group_5bf63ad55a01d","","","2018-11-26 00:06:34","2018-11-26 00:06:34","","0","http://localhost/immigration/?post_type=acf-field-group&#038;p=98","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("99","1","2018-11-22 05:15:04","2018-11-22 05:15:04","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Intro A","intro_a","publish","closed","closed","","field_5bf63aebb2d16","","","2018-11-23 00:12:51","2018-11-23 00:12:51","","98","http://localhost/immigration/?post_type=acf-field&#038;p=99","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES("100","1","2018-11-22 05:15:04","2018-11-22 05:15:04","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Intro B","intro_b","publish","closed","closed","","field_5bf63b12b2d17","","","2018-11-23 00:12:38","2018-11-23 00:12:38","","98","http://localhost/immigration/?post_type=acf-field&#038;p=100","1","acf-field","","0");
INSERT INTO `wp_posts` VALUES("101","1","2018-11-22 05:52:43","2018-11-22 05:52:43","","Lawyer","","trash","closed","closed","","lawyer__trashed","","","2018-11-22 23:39:21","2018-11-22 23:39:21","","9","http://localhost/immigration/?page_id=101","0","page","","0");
INSERT INTO `wp_posts` VALUES("102","1","2018-11-22 05:52:43","2018-11-22 05:52:43","","Lawyer","","inherit","closed","closed","","101-revision-v1","","","2018-11-22 05:52:43","2018-11-22 05:52:43","","101","http://localhost/immigration/index.php/2018/11/22/101-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("103","1","2018-11-23 01:11:18","2018-11-23 01:11:18","{
    \"law-master::heading_color_setting\": {
        \"value\": \"#22acd6\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 01:11:18\"
    },
    \"law-master::logo_setting\": {
        \"value\": \"\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 01:10:44\"
    }
}","","","trash","closed","closed","","ccb00a59-9602-4805-81cf-399e8e2dd217","","","2018-11-23 01:11:18","2018-11-23 01:11:18","","0","http://localhost/immigration/?p=103","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("104","1","2018-11-23 01:15:03","0000-00-00 00:00:00","{
    \"law-master::heading_color_setting\": {
        \"value\": \"#23b4e0\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 01:15:03\"
    }
}","","","auto-draft","closed","closed","","51003e34-abff-4dc9-904d-d068994a3930","","","2018-11-23 01:15:03","0000-00-00 00:00:00","","0","http://localhost/immigration/?p=104","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("105","1","2018-11-25 23:57:42","2018-11-25 23:57:42","a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}","Content","content","publish","closed","closed","","field_5bfb36effd675","","","2018-11-26 00:06:34","2018-11-26 00:06:34","","98","http://localhost/immigration/?post_type=acf-field&#038;p=105","2","acf-field","","0");
INSERT INTO `wp_posts` VALUES("106","1","2018-11-26 00:21:51","2018-11-26 00:21:51","","Testimonials","","publish","closed","closed","","testimonials","","","2018-11-26 00:23:39","2018-11-26 00:23:39","","0","http://localhost/immigration/?p=106","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("107","1","2018-11-26 00:22:07","2018-11-26 00:22:07","","Testimonials","","publish","closed","closed","","testimonials","","","2018-11-26 00:22:07","2018-11-26 00:22:07","","0","http://localhost/immigration/?post_type=section&#038;p=107","4","section","","0");
INSERT INTO `wp_posts` VALUES("108","1","2018-11-26 00:22:24","2018-11-26 00:22:24","Home","Home","","inherit","closed","closed","","9-revision-v1","","","2018-11-26 00:22:24","2018-11-26 00:22:24","","9","http://localhost/immigration/index.php/2018/11/26/9-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("109","1","2018-11-26 00:34:19","2018-11-26 00:34:19","","Aarzoo Kaur","","publish","closed","closed","","aarzoo-kaur","","","2018-11-26 00:35:29","2018-11-26 00:35:29","","0","http://localhost/immigration/?post_type=testimonial&#038;p=109","0","testimonial","","0");
INSERT INTO `wp_posts` VALUES("110","1","2018-11-26 00:35:02","2018-11-26 00:35:02","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:11:\"testimonial\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}","Testimonials Fields","testimonials-fields","publish","closed","closed","","group_5bfb3f94219d4","","","2018-11-26 00:35:02","2018-11-26 00:35:02","","0","http://localhost/immigration/?post_type=acf-field-group&#038;p=110","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("111","1","2018-11-26 00:35:02","2018-11-26 00:35:02","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","content","content","publish","closed","closed","","field_5bfb3faf22361","","","2018-11-26 00:35:02","2018-11-26 00:35:02","","110","http://localhost/immigration/?post_type=acf-field&p=111","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES("112","1","2018-11-26 00:35:32","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-26 00:35:32","0000-00-00 00:00:00","","0","http://localhost/immigration/?post_type=testimonial&p=112","0","testimonial","","0");
INSERT INTO `wp_posts` VALUES("113","1","2018-11-26 00:35:41","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-26 00:35:41","0000-00-00 00:00:00","","0","http://localhost/immigration/?post_type=acf-field-group&p=113","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("114","1","2018-11-26 00:35:41","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-26 00:35:41","0000-00-00 00:00:00","","0","http://localhost/immigration/?post_type=acf-field-group&p=114","0","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES("115","1","2018-11-26 00:36:03","2018-11-26 00:36:03","","Gurpreet Kaur","","publish","closed","closed","","gurpreet-kaur","","","2018-11-26 00:36:03","2018-11-26 00:36:03","","0","http://localhost/immigration/?post_type=testimonial&#038;p=115","0","testimonial","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");
INSERT INTO `wp_term_relationships` VALUES("26","2","0");
INSERT INTO `wp_term_relationships` VALUES("27","2","0");
INSERT INTO `wp_term_relationships` VALUES("28","2","0");
INSERT INTO `wp_term_relationships` VALUES("38","2","0");
INSERT INTO `wp_term_relationships` VALUES("45","2","0");
INSERT INTO `wp_term_relationships` VALUES("97","2","0");
INSERT INTO `wp_term_relationships` VALUES("106","2","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","nav_menu","","0","7");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Uncategorized","uncategorized","0");
INSERT INTO `wp_terms` VALUES("2","main-menu","main-menu","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","wizardshao");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","wp496_privacy");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"9d38ce91c4ef1fd62a48260f2bcd123717b35aedffa88b0c27ddb8b36929be9c\";a:4:{s:10:\"expiration\";i:1543360678;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36\";s:5:\"login\";i:1543187878;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","4");
INSERT INTO `wp_usermeta` VALUES("18","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","metaboxhidden_nav-menus","a:2:{i:0;s:19:\"add-post-type-slide\";i:1;s:12:\"add-post_tag\";}");
INSERT INTO `wp_usermeta` VALUES("20","1","nav_menu_recently_edited","2");
INSERT INTO `wp_usermeta` VALUES("21","1","wp_user-settings","libraryContent=browse");
INSERT INTO `wp_usermeta` VALUES("22","1","wp_user-settings-time","1542843988");
INSERT INTO `wp_usermeta` VALUES("23","1","wp_yoast_notifications","a:3:{i:0;a:2:{s:7:\"message\";s:536:\"Yoast SEO and Advanced Custom Fields can work together a lot better by adding a helper plugin. Please install <a href=\"http://localhost/immigration/wp-admin/update.php?action=install-plugin&amp;plugin=acf-content-analysis-for-yoast-seo&amp;_wpnonce=8db19b3a41\">ACF Content Analysis for Yoast SEO</a> to make your life better. <a href=\"https://wordpress.org/plugins/acf-content-analysis-for-yoast-seo/\" aria-label=\"More information about ACF Content Analysis for Yoast SEO\" target=\"_blank\" rel=\"noopener noreferrer\">More information</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:41:\"wpseo-suggested-plugin-yoast-acf-analysis\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:171:\"Don\'t miss your crawl errors: <a href=\"http://localhost/immigration/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:2;a:2:{s:7:\"message\";s:328:\"You still have the default WordPress tagline, even an empty one is probably better. <a href=\"http://localhost/immigration/wp-admin/customize.php?autofocus[control]=blogdescription&amp;url=http%3A%2F%2Flocalhost%2Fimmigration%2Fwp-admin%2Fadmin.php%3Fpage%3Daiowpsec_database%26tab%3Dtab2\">You can fix this in the customizer</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:5:\"error\";s:2:\"id\";s:28:\"wpseo-dismiss-tagline-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES("1","wizardshao","$P$BKn6//UlZg1bWjWPaXTlub.mTP5hOs1","wizardshao","st.havac@gmail.com","","2018-11-20 02:43:28","","0","wizardshao");


DROP TABLE IF EXISTS `wp_yoast_seo_links`;

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_meta`;

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



